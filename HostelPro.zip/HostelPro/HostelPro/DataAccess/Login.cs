﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using HostelPro.Models;

namespace HostelPro.DataAccess
{
    public class Login
    {
        public void Add()
        {
            //Salt = GenerateSalt();
            //Hash = HashPassword(Password);

            //using (masterContext mc = new masterContext())
            //{
            //    mc.Add(this);
            //    mc.SaveChanges();
            //}
        }



       
    }
}